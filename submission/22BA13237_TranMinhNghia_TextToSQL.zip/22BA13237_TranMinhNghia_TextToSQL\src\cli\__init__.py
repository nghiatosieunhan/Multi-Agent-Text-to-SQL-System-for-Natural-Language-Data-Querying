"""src/cli package."""
