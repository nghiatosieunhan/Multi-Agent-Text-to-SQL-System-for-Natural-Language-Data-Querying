# Init for app module
